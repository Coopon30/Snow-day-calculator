const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname)));

app.get('/predict', (req, res) => {
    const zipCode = req.query.zip;
    const data = JSON.parse(fs.readFileSync('./data/school-records.json', 'utf8'));
    
    // Simulate prediction logic based on past records
    const prediction = data[zipCode] && data[zipCode].snow_days > data[zipCode].total_days * 0.2
        ? 'snow_day'
        : 'no_snow_day';

    res.json({ prediction });
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});